package com.vipun.task.enums;

public enum TaskStatus {

    PENDING,
    INPROGRESS,
    COMPLETED,
    DEFERRED,
    CANCELED
}
