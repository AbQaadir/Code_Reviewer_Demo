package com.vipun.task.enums;

import com.vipun.task.entities.User;

public enum UserRole {

    ADMIN,EMPLOYEE;

}
